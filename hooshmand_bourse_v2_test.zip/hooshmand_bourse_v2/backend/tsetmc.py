"""Conservative TSETMC connectivity probes. No signals are generated here."""
from __future__ import annotations
import httpx

BASE = "https://cdn.tsetmc.com/api"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126 Safari/537.36",
    "Accept": "application/json,text/plain,*/*",
    "Referer": "https://www.tsetmc.com/",
    "Origin": "https://www.tsetmc.com",
}

async def probe_tsetmc() -> dict:
    checks = []
    async with httpx.AsyncClient(headers=HEADERS, timeout=12.0, follow_redirects=True) as client:
        probes = [
            ("جست‌وجوی نماد برای آزمایش مسیر داده", f"{BASE}/Instrument/GetInstrumentSearch/%D8%AE%DA%AF%D8%B3%D8%AA%D8%B1"),
            ("دیده‌بان بازار", f"{BASE}/ClosingPrice/GetMarketWatch?market=0&paperTypes%5B0%5D=1&paperTypes%5B1%5D=2&withBestLimits=false&hEven=0&RefID=0"),
        ]
        for label, url in probes:
            try:
                r = await client.get(url)
                ctype = r.headers.get("content-type", "")
                body = r.text[:500]
                is_json = False
                count = None
                try:
                    data = r.json()
                    is_json = True
                    if isinstance(data, dict):
                        for v in data.values():
                            if isinstance(v, list):
                                count = len(v)
                                break
                except Exception:
                    pass
                checks.append({"name": label, "http_status": r.status_code,
                               "content_type": ctype, "json": is_json,
                               "record_count": count,
                               "ok": r.status_code == 200 and is_json and (count is None or count > 0),
                               "sample": body[:180]})
            except Exception as e:
                checks.append({"name": label, "ok": False, "error": type(e).__name__ + ": " + str(e)[:180]})
    all_ok = all(x.get("ok") for x in checks)
    return {
        "status": "connected" if all_ok else "not_verified",
        "checks": checks,
        "note": "اتصال فقط وقتی تأیید می‌شود که پاسخ معتبر و داده قابل استفاده دریافت شود؛ پاسخ خالی یا خطای شبکه موفقیت محسوب نمی‌شود."
    }
