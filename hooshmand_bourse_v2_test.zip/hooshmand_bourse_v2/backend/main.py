from datetime import datetime, timezone
from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from backend.tsetmc import probe_tsetmc

app = FastAPI(title="هوشمند بورس ایران", version="0.2.0")

@app.get("/api/health")
async def health():
    return {"status": "ok", "version": "0.2.0", "time_utc": datetime.now(timezone.utc).isoformat()}

@app.get("/api/connection-test")
async def connection_test():
    """Probe TSETMC from the server where this app is deployed."""
    return await probe_tsetmc()

@app.get("/api/market-scan")
async def market_scan():
    # Intentionally returns no fabricated opportunities.
    return {
        "status": "awaiting_verified_market_feed",
        "market_coverage": "not_connected",
        "scanned_symbols": 0,
        "opportunities": [],
        "message": "تا اتصال و اعتبارسنجی فهرست و داده زنده کل بازار، فرصت یا سیگنال ساختگی نمایش داده نمی‌شود."
    }

@app.get("/api/alerts/status")
async def alert_status():
    return {
        "in_app_alerts": "ui_ready",
        "push_alerts": "requires_https_and_push_service",
        "triggered_alerts": [],
        "message": "هشدار واقعی پس از اتصال داده معتبر و تأیید کاربر فعال می‌شود."
    }

@app.get("/", response_class=HTMLResponse)
async def home():
    return (Path(__file__).resolve().parent.parent / "frontend" / "index.html").read_text(encoding="utf-8")
